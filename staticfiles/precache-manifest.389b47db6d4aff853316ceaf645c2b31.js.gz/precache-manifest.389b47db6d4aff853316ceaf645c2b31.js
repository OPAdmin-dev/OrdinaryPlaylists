self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "01ecc287c81242a002c32d1de34a683c",
    "url": "/index.html"
  },
  {
    "revision": "9112347a77bfc7bd1ba6",
    "url": "/static/css/2.39e3ff75.chunk.css"
  },
  {
    "revision": "d797b82c9698b7fa099b",
    "url": "/static/css/main.df19ac53.chunk.css"
  },
  {
    "revision": "9112347a77bfc7bd1ba6",
    "url": "/static/js/2.ef8790d7.chunk.js"
  },
  {
    "revision": "d2f6fd07c008f65640a8414d7be30a2d",
    "url": "/static/js/2.ef8790d7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d797b82c9698b7fa099b",
    "url": "/static/js/main.5d5d098f.chunk.js"
  },
  {
    "revision": "2747b914e9a60db2276f",
    "url": "/static/js/runtime-main.c8a21426.js"
  },
  {
    "revision": "f05596956c57506d2ebfbe4fd72197e5",
    "url": "/static/media/Card.f0559695.png"
  },
  {
    "revision": "04d9fabf76fe9a283a1531b7185ede91",
    "url": "/static/media/GT-Cinetype-Light-Trial.04d9fabf.woff2"
  },
  {
    "revision": "12155c240806924a8a818fe83dbbac7b",
    "url": "/static/media/RLC_03-min.12155c24.png"
  },
  {
    "revision": "44cad8f7b19beffa4ba2d80ae3039478",
    "url": "/static/media/RoxboroughCF-Regular.44cad8f7.woff"
  },
  {
    "revision": "ee4dc85c8b84177b44ddc0119c806583",
    "url": "/static/media/book-min.ee4dc85c.jpeg"
  },
  {
    "revision": "d59ab9ef51fe10a673ce923dafe259f3",
    "url": "/static/media/music.d59ab9ef.svg"
  },
  {
    "revision": "78f114f4014ff73917686403630ba929",
    "url": "/static/media/note.78f114f4.svg"
  }
]);